<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] != 'usuario') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'Não autorizado.'], JSON_UNESCAPED_UNICODE);
    exit();
}

if (!isset($_GET['id'])) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'message' => 'ID da reserva não fornecido.'], JSON_UNESCAPED_UNICODE);
    exit();
}

$database = new Database();
$db = $database->getConnection();

$id_reserva = $_GET['id'];
$id_usuario = $_SESSION['usuario_id'];

header('Content-Type: application/json; charset=utf-8');

try {
    // Verificar se a reserva pertence ao usuário
    $query_verificar = "SELECT * FROM reservas WHERE id_reserva = :id_reserva AND id_usuario = :id_usuario";
    $stmt_verificar = $db->prepare($query_verificar);
    $stmt_verificar->bindParam(":id_reserva", $id_reserva);
    $stmt_verificar->bindParam(":id_usuario", $id_usuario);
    $stmt_verificar->execute();

    if ($stmt_verificar->rowCount() == 0) {
        echo json_encode([
            'success' => false, 
            'message' => 'Reserva não encontrada ou você não tem permissão para cancelá-la.'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $reserva = $stmt_verificar->fetch(PDO::FETCH_ASSOC);

    if ($reserva['status'] == 'cancelada') {
        echo json_encode([
            'success' => false, 
            'message' => 'Esta reserva já está cancelada.'
        ], JSON_UNESCAPED_UNICODE);
        exit();
    }

    // Atualizar status para cancelada
    $query_cancelar = "UPDATE reservas SET status = 'cancelada' WHERE id_reserva = :id_reserva";
    $stmt_cancelar = $db->prepare($query_cancelar);
    $stmt_cancelar->bindParam(":id_reserva", $id_reserva);

    if ($stmt_cancelar->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Reserva cancelada com sucesso!'
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Erro ao cancelar reserva. Tente novamente.'
        ], JSON_UNESCAPED_UNICODE);
    }

} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Erro no sistema: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>