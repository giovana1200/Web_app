<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// SE FOR ADMIN, REDIRECIONA PARA O PAINEL DO ADMIN
if ($_SESSION['usuario_tipo'] === 'admin') {
    header("Location: admin_dashboard.php");
    exit();
}

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

// Buscar eventos
$query = "SELECT * FROM eventos WHERE data_evento >= CURDATE() ORDER BY data_evento, hora";
$stmt = $db->prepare($query);
$stmt->execute();
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos - Reservas Culturais</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
        }
        .card-event {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
        }
        .card-event:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .event-image {
            height: 200px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 3rem;
        }
        .navbar-brand {
            font-weight: 600;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
        <div class="container">
            <a class="navbar-brand fw-bold" href="dashboard.php">
                <i class="fas fa-theater-masks me-2"></i>Reservas Culturais
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    <i class="fas fa-user me-1"></i>Olá, <?php echo $_SESSION['usuario_nome']; ?>
                </span>
                <a class="btn btn-outline-light btn-sm" href="logout.php">
                    <i class="fas fa-sign-out-alt me-1"></i>Sair
                </a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container text-center">
            <h1 class="display-4 fw-bold mb-3">Descubra Eventos Incríveis</h1>
            <p class="lead mb-4">Reserve seu lugar nos melhores eventos culturais da cidade</p>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="d-flex gap-2 justify-content-center">
                        <span class="badge bg-light text-dark p-2"><i class="fas fa-music me-1"></i>Música</span>
                        <span class="badge bg-light text-dark p-2"><i class="fas fa-palette me-1"></i>Arte</span>
                        <span class="badge bg-light text-dark p-2"><i class="fas fa-theater-masks me-1"></i>Teatro</span>
                        <span class="badge bg-light text-dark p-2"><i class="fas fa-dance me-1"></i>Dança</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Filtros -->
    <section class="py-4 bg-light">
        <div class="container">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label fw-semibold">Buscar evento</label>
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
                        <input type="text" id="busca" class="form-control" placeholder="Digite o nome do evento...">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Data</label>
                    <input type="date" id="filtro-data" class="form-control">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-semibold">Local</label>
                    <select id="filtro-local" class="form-select">
                        <option value="">Todos os locais</option>
                        <option value="São Paulo">São Paulo</option>
                        <option value="Rio de Janeiro">Rio de Janeiro</option>
                        <option value="Belo Horizonte">Belo Horizonte</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button class="btn btn-outline-secondary w-100" onclick="limparFiltros()">
                        <i class="fas fa-times me-1"></i>Limpar
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Lista de Eventos -->
    <section class="py-5">
        <div class="container">
            <h2 class="mb-4 fw-bold">Próximos Eventos</h2>
            
            <?php if (empty($eventos)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">Nenhum evento encontrado</h4>
                    <p class="text-muted">Não há eventos programados no momento.</p>
                </div>
            <?php else: ?>
                <div class="row g-4" id="lista-eventos">
                    <?php foreach ($eventos as $evento): ?>
                    <div class="col-lg-4 col-md-6">
                        <div class="card card-event h-100" data-evento='<?php echo json_encode($evento); ?>'>
                            <div class="event-image rounded-top">
                                🎭
                            </div>
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title fw-bold"><?php echo $evento['nome']; ?></h5>
                                
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="fas fa-map-marker-alt me-1"></i>
                                        <?php echo $evento['local']; ?>
                                    </small>
                                </div>
                                
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="far fa-calendar me-1"></i>
                                        <?php echo date('d/m/Y', strtotime($evento['data_evento'])); ?> às <?php echo date('H:i', strtotime($evento['hora'])); ?>
                                    </small>
                                </div>
                                
                                <div class="mb-2">
                                    <small class="text-muted">
                                        <i class="fas fa-users me-1"></i>
                                        <?php echo $evento['capacidade']; ?> vagas disponíveis
                                    </small>
                                </div>
                                
                                <div class="alert alert-light py-2 mb-3" id="clima-<?php echo $evento['id_evento']; ?>">
                                    <small class="d-flex align-items-center">
                                        <i class="fas fa-cloud-sun me-2"></i>
                                        <span>Carregando previsão...</span>
                                    </small>
                                </div>
                                
                                <p class="card-text flex-grow-1 text-muted">
                                    <?php echo substr($evento['descricao'], 0, 100); ?>...
                                </p>
                                
                                <button class="btn btn-primary mt-auto" onclick="verDetalhes(<?php echo $evento['id_evento']; ?>)">
                                    <i class="fas fa-info-circle me-1"></i>Ver Detalhes
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h5 class="fw-bold">🎭 Reservas Culturais</h5>
                    <p class="mb-0 text-muted">Sua plataforma de eventos culturais</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p class="mb-0">&copy; 2025 Sistema de Reservas Culturais. Todos os direitos reservados.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Filtros
        document.getElementById('busca').addEventListener('input', filtrarEventos);
        document.getElementById('filtro-data').addEventListener('change', filtrarEventos);
        document.getElementById('filtro-local').addEventListener('change', filtrarEventos);
        
        function filtrarEventos() {
            const busca = document.getElementById('busca').value.toLowerCase();
            const data = document.getElementById('filtro-data').value;
            const local = document.getElementById('filtro-local').value;
            
            document.querySelectorAll('.card-event').forEach(card => {
                const evento = JSON.parse(card.dataset.evento);
                const nomeMatch = evento.nome.toLowerCase().includes(busca);
                const dataMatch = !data || evento.data_evento === data;
                const localMatch = !local || evento.local.includes(local);
                
                card.closest('.col-lg-4').style.display = (nomeMatch && dataMatch && localMatch) ? 'block' : 'none';
            });
        }
        
        function limparFiltros() {
            document.getElementById('busca').value = '';
            document.getElementById('filtro-data').value = '';
            document.getElementById('filtro-local').value = '';
            filtrarEventos();
        }
        
        // Clima
        document.querySelectorAll('.card-event').forEach(card => {
            const evento = JSON.parse(card.dataset.evento);
            carregarClima(evento.id_evento, evento.local, evento.data_evento);
        });
        
        function carregarClima(idEvento, local, dataEvento) {
            const climas = [
                { texto: '🌞 Ensolarado', icon: 'fa-sun', temp: Math.floor(Math.random() * 10) + 25 },
                { texto: '🌧️ Chuvoso', icon: 'fa-cloud-rain', temp: Math.floor(Math.random() * 8) + 18 },
                { texto: '⛅ Parcialmente nublado', icon: 'fa-cloud-sun', temp: Math.floor(Math.random() * 8) + 22 },
                { texto: '☁️ Nublado', icon: 'fa-cloud', temp: Math.floor(Math.random() * 8) + 20 }
            ];
            const clima = climas[Math.floor(Math.random() * climas.length)];
            
            setTimeout(() => {
                document.getElementById(`clima-${idEvento}`).innerHTML = 
                    `<small class="d-flex align-items-center">
                        <i class="fas ${clima.icon} me-2"></i>
                        <span>${clima.texto} - ${clima.temp}°C</span>
                    </small>`;
            }, 1000 + Math.random() * 2000);
        }
        
        function verDetalhes(idEvento) {
            window.location.href = `detalhes_evento.php?id=${idEvento}`;
        }
    </script>
</body>
</html>