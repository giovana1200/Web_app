<?php
session_start();
require_once 'config/database.php';

// Verificar se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] != 'admin') {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Buscar todos os eventos
$query = "SELECT *,
          (SELECT SUM(quantidade_pessoas) FROM reservas WHERE reservas.id_evento = eventos.id_evento AND status = 'confirmada') as total_reservas
          FROM eventos 
          ORDER BY data_evento DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Eventos - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .evento-card {
            transition: transform 0.2s;
        }
        .evento-card:hover {
            transform: translateY(-2px);
        }
        .stats-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="admin_dashboard.php">
                <i class="fas fa-theater-masks me-2"></i>Reservas Culturais - Admin
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="admin_dashboard.php"><i class="fas fa-tachometer-alt me-1"></i>Dashboard</a>
                <a class="nav-link active" href="admin_eventos.php"><i class="fas fa-calendar-alt me-1"></i>Eventos</a>
                <a class="nav-link" href="admin_usuarios.php"><i class="fas fa-users me-1"></i>Usuários</a>
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Sair</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="fas fa-calendar-alt me-2"></i>Gerenciar Eventos</h2>
            <a href="adicionar_evento.php" class="btn btn-success">
                <i class="fas fa-plus me-2"></i>Adicionar Evento
            </a>
        </div>

        <?php if (isset($_SESSION['sucesso'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?php echo $_SESSION['sucesso']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['sucesso']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['erro'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $_SESSION['erro']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['erro']); ?>
        <?php endif; ?>

        <!-- Estatísticas Rápidas -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card p-3 text-center">
                    <h4><i class="fas fa-calendar me-2"></i><?php echo count($eventos); ?></h4>
                    <p class="mb-0">Total de Eventos</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card p-3 text-center" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
                    <h4><i class="fas fa-users me-2"></i>
                        <?php 
                        $total_reservas = 0;
                        foreach ($eventos as $evento) {
                            $total_reservas += $evento['total_reservas'] ?? 0;
                        }
                        echo $total_reservas;
                        ?>
                    </h4>
                    <p class="mb-0">Total de Reservas</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card p-3 text-center" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
                    <h4><i class="fas fa-calendar-check me-2"></i>
                        <?php 
                        $eventos_futuros = array_filter($eventos, function($evento) {
                            return strtotime($evento['data_evento']) >= strtotime(date('Y-m-d'));
                        });
                        echo count($eventos_futuros);
                        ?>
                    </h4>
                    <p class="mb-0">Eventos Futuros</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card p-3 text-center" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
                    <h4><i class="fas fa-eye me-2"></i>
                        <?php 
                        $eventos_publicos = array_filter($eventos, function($evento) {
                            return ($evento['total_reservas'] ?? 0) < $evento['capacidade'];
                        });
                        echo count($eventos_publicos);
                        ?>
                    </h4>
                    <p class="mb-0">Com Vagas</p>
                </div>
            </div>
        </div>

        <!-- Lista de Eventos -->
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-list me-2"></i>Lista de Eventos</h5>
            </div>
            <div class="card-body">
                <?php if (count($eventos) > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Data</th>
                                    <th>Local</th>
                                    <th>Capacidade</th>
                                    <th>Reservas</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($eventos as $evento): 
                                    $total_reservas_evento = $evento['total_reservas'] ?? 0;
                                    $porcentagem = $evento['capacidade'] > 0 ? ($total_reservas_evento / $evento['capacidade']) * 100 : 0;
                                    $status_class = $porcentagem >= 100 ? 'danger' : ($porcentagem >= 80 ? 'warning' : 'success');
                                ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo $evento['nome']; ?></strong>
                                            <?php if (strtotime($evento['data_evento']) < strtotime(date('Y-m-d'))): ?>
                                                <span class="badge bg-secondary ms-1">Encerrado</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo date('d/m/Y', strtotime($evento['data_evento'])); ?><br>
                                            <small class="text-muted"><?php echo date('H:i', strtotime($evento['hora'])); ?>h</small>
                                        </td>
                                        <td><?php echo $evento['local']; ?></td>
                                        <td><?php echo $evento['capacidade']; ?></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="progress flex-grow-1 me-2" style="height: 8px;">
                                                    <div class="progress-bar bg-<?php echo $status_class; ?>" 
                                                         style="width: <?php echo min(100, $porcentagem); ?>%">
                                                    </div>
                                                </div>
                                                <span class="small"><?php echo $total_reservas_evento; ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?php echo $status_class; ?>">
                                                <?php echo number_format($porcentagem, 1); ?>%
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="detalhes_evento.php?id=<?php echo $evento['id_evento']; ?>" 
                                                   class="btn btn-outline-primary" title="Ver">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="editar_evento.php?id=<?php echo $evento['id_evento']; ?>" 
                                                   class="btn btn-outline-warning" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="excluir_evento.php?id=<?php echo $evento['id_evento']; ?>" 
                                                   class="btn btn-outline-danger" 
                                                   onclick="return confirm('Tem certeza que deseja excluir este evento?')"
                                                   title="Excluir">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                        <h4 class="text-muted">Nenhum evento cadastrado</h4>
                        <p class="text-muted">Comece adicionando seu primeiro evento.</p>
                        <a href="adicionar_evento.php" class="btn btn-success">
                            <i class="fas fa-plus me-2"></i>Adicionar Primeiro Evento
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>