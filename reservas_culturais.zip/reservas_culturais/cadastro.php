<?php
session_start();
require_once 'config/database.php';

if ($_POST) {
    $database = new Database();
    $db = $database->getConnection();
    
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $confirmar_senha = $_POST['confirmar_senha'];
    
    // Validações
    $erro = '';
    
    if (strlen($senha) < 8) {
        $erro = "A senha deve ter pelo menos 8 caracteres";
    } elseif (!preg_match('/[A-Za-z].*[0-9]|[0-9].*[A-Za-z]/', $senha)) {
        $erro = "A senha deve conter letras e números";
    } elseif ($senha !== $confirmar_senha) {
        $erro = "As senhas não coincidem";
    } else {
        // Verificar se email já existe
        $query = "SELECT id_usuario FROM usuarios WHERE email = :email";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":email", $email);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $erro = "Este email já está cadastrado";
        } else {
            // Inserir novo usuário - REMOVIDO primeiro_acesso
            $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
            $query = "INSERT INTO usuarios (nome, email, senha, tipo) 
                      VALUES (:nome, :email, :senha, 'usuario')";
            $stmt = $db->prepare($query);
            $stmt->bindParam(":nome", $nome);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":senha", $senha_hash);
            
            if ($stmt->execute()) {
                $sucesso = "Cadastro realizado com sucesso! Faça login para continuar.";
            } else {
                $erro = "Erro ao cadastrar. Tente novamente.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - Reservas Culturais</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .cadastro-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body class="gradient-bg">
    <div class="container d-flex justify-content-center align-items-center min-vh-100 py-4">
        <div class="card cadastro-card" style="width: 100%; max-width: 450px;">
            <div class="card-body p-4">
                <div class="text-center mb-4">
                    <h2 class="card-title fw-bold">🎭 Criar Conta</h2>
                    <p class="text-muted">Preencha os dados para se cadastrar</p>
                </div>

                <?php if (isset($erro)): ?>
                    <div class="alert alert-danger d-flex align-items-center">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        <?php echo $erro; ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($sucesso)): ?>
                    <div class="alert alert-success d-flex align-items-center">
                        <i class="fas fa-check-circle me-2"></i>
                        <?php echo $sucesso; ?>
                    </div>
                    <div class="text-center">
                        <a href="login.php" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt me-1"></i>Fazer Login
                        </a>
                    </div>
                <?php else: ?>

                <form method="POST">
                    <div class="mb-3">
                        <label for="nome" class="form-label fw-semibold">Nome Completo</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                            <input type="text" class="form-control" id="nome" name="nome" 
                                   value="<?php echo $_POST['nome'] ?? ''; ?>" 
                                   placeholder="Seu nome completo" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label fw-semibold">E-mail</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                            <input type="email" class="form-control" id="email" name="email" 
                                   value="<?php echo $_POST['email'] ?? ''; ?>" 
                                   placeholder="seu@email.com" required>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="senha" class="form-label fw-semibold">Senha</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="senha" name="senha" 
                                   placeholder="Crie uma senha" required>
                        </div>
                        <div class="form-text">
                            <small>A senha deve ter pelo menos 8 caracteres com letras e números</small>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="confirmar_senha" class="form-label fw-semibold">Confirmar Senha</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-lock"></i></span>
                            <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" 
                                   placeholder="Confirme sua senha" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                        <i class="fas fa-user-plus me-2"></i>Criar Conta
                    </button>
                </form>
                
                <div class="text-center">
                    <a href="login.php" class="text-decoration-none">
                        <i class="fas fa-arrow-left me-1"></i>Voltar para o Login
                    </a>
                </div>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>