<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: evento.php"); // CORREÇÃO: evento.php (singular)
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Buscar detalhes do evento
$query_evento = "SELECT * FROM eventos WHERE id_evento = :id";
$stmt_evento = $db->prepare($query_evento);
$stmt_evento->bindParam(":id", $_GET['id']);
$stmt_evento->execute();
$evento = $stmt_evento->fetch(PDO::FETCH_ASSOC);

if (!$evento) {
    header("Location: evento.php"); // CORREÇÃO: evento.php (singular)
    exit();
}

// CORREÇÃO: Verificar reservas existentes CONFIRMADAS do usuário para este evento
$query_reserva = "SELECT * FROM reservas WHERE id_usuario = :usuario_id AND id_evento = :evento_id AND status = 'confirmada'";
$stmt_reserva = $db->prepare($query_reserva);
$stmt_reserva->bindParam(":usuario_id", $_SESSION['usuario_id']);
$stmt_reserva->bindParam(":evento_id", $_GET['id']);
$stmt_reserva->execute();
$reserva_existente = $stmt_reserva->fetch(PDO::FETCH_ASSOC);

// CORREÇÃO: Já está correto - conta apenas reservas confirmadas
$query_total_reservas = "SELECT SUM(quantidade_pessoas) as total FROM reservas WHERE id_evento = :evento_id AND status = 'confirmada'";
$stmt_total = $db->prepare($query_total_reservas);
$stmt_total->bindParam(":evento_id", $_GET['id']);
$stmt_total->execute();
$total_reservas = $stmt_total->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
$vagas_disponiveis = $evento['capacidade'] - $total_reservas;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $evento['nome']; ?> - Reservas Culturais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-theater-masks me-2"></i>Reservas Culturais
            </a>
            <div class="navbar-nav ms-auto">
                <!-- CORREÇÃO: evento.php (singular) -->
                <a class="nav-link" href="evento.php"><i class="fas fa-calendar me-1"></i>Eventos</a>
                <a class="nav-link" href="minhas_reservas.php"><i class="fas fa-calendar-check me-1"></i>Minhas Reservas</a>
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Sair</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><i class="fas fa-info-circle me-2"></i>Detalhes do Evento</h4>
                    </div>
                    <div class="card-body">
                        <h3 class="card-title"><?php echo $evento['nome']; ?></h3>
                        <p class="card-text"><?php echo $evento['descricao']; ?></p>
                        
                        <div class="row mt-4">
                            <div class="col-md-6">
                                <h5><i class="fas fa-map-marker-alt text-primary me-2"></i>Localização</h5>
                                <p class="mb-1"><strong>Local:</strong> <?php echo $evento['local']; ?></p>
                                <?php if ($evento['endereco_completo']): ?>
                                    <p class="mb-1"><strong>Endereço:</strong> <?php echo $evento['endereco_completo']; ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="col-md-6">
                                <h5><i class="fas fa-calendar-day text-primary me-2"></i>Data e Hora</h5>
                                <p class="mb-1"><strong>Data:</strong> <?php echo date('d/m/Y', strtotime($evento['data_evento'])); ?></p>
                                <p class="mb-1"><strong>Horário:</strong> <?php echo date('H:i', strtotime($evento['hora'])); ?>h</p>
                            </div>
                        </div>

                        <div class="mt-4">
                            <h5><i class="fas fa-users text-primary me-2"></i>Capacidade</h5>
                            <div class="progress mb-2" style="height: 25px;">
                                <div class="progress-bar 
                                    <?php echo ($total_reservas / $evento['capacidade'] * 100) > 80 ? 'bg-warning' : 'bg-success'; ?>" 
                                    role="progressbar" 
                                    style="width: <?php echo min(100, ($total_reservas / $evento['capacidade'] * 100)); ?>%"
                                    aria-valuenow="<?php echo $total_reservas; ?>" 
                                    aria-valuemin="0" 
                                    aria-valuemax="<?php echo $evento['capacidade']; ?>">
                                    <?php echo $total_reservas; ?> / <?php echo $evento['capacidade']; ?> reservas
                                </div>
                            </div>
                            <p class="text-muted">Vagas disponíveis: <strong><?php echo $vagas_disponiveis; ?></strong></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0"><i class="fas fa-ticket-alt me-2"></i>Fazer Reserva</h5>
                    </div>
                    <div class="card-body">
                        <?php if ($reserva_existente): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-info-circle me-2"></i>
                                <!-- CORREÇÃO: Texto atualizado -->
                                Você já possui uma reserva CONFIRMADA para este evento.
                                <br><strong>Status:</strong> <?php echo ucfirst($reserva_existente['status']); ?>
                                <br><strong>Pessoas:</strong> <?php echo $reserva_existente['quantidade_pessoas']; ?>
                                <br><a href="minhas_reservas.php" class="btn btn-sm btn-primary mt-2">Ver Minhas Reservas</a>
                            </div>
                        <?php elseif ($vagas_disponiveis <= 0): ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Evento lotado! Não há vagas disponíveis.
                            </div>
                        <?php else: ?>
                            <form action="processar_reserva.php" method="POST">
                                <input type="hidden" name="id_evento" value="<?php echo $evento['id_evento']; ?>">
                                
                                <div class="mb-3">
                                    <label for="quantidade_pessoas" class="form-label">Número de Pessoas</label>
                                    <select class="form-select" id="quantidade_pessoas" name="quantidade_pessoas" required>
                                        <?php for ($i = 1; $i <= min(10, $vagas_disponiveis); $i++): ?>
                                            <option value="<?php echo $i; ?>"><?php echo $i; ?> pessoa<?php echo $i > 1 ? 's' : ''; ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <small class="text-muted">Máximo de <?php echo min(10, $vagas_disponiveis); ?> pessoas por reserva</small>
                                </div>

                                <button type="submit" class="btn btn-success w-100">
                                    <i class="fas fa-check me-2"></i>Confirmar Reserva
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card mt-3">
                    <div class="card-body text-center">
                        <!-- CORREÇÃO: evento.php (singular) -->
                        <a href="evento.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i>Voltar para Eventos
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>