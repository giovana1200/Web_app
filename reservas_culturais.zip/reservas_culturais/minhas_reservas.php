<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// CORREÇÃO: Buscar apenas reservas CONFIRMADAS do usuário
$query = "SELECT r.*, e.nome as evento_nome, e.data_evento, e.hora, e.local, e.descricao 
          FROM reservas r 
          JOIN eventos e ON r.id_evento = e.id_evento 
          WHERE r.id_usuario = :usuario_id AND r.status = 'confirmada'
          ORDER BY e.data_evento ASC, r.data_reserva DESC";
$stmt = $db->prepare($query);
$stmt->bindParam(":usuario_id", $_SESSION['usuario_id']);
$stmt->execute();
$reservas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minhas Reservas - Reservas Culturais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-theater-masks me-2"></i>Reservas Culturais
            </a>
            <div class="navbar-nav ms-auto">
                <a class="nav-link" href="evento.php"><i class="fas fa-calendar me-1"></i>Eventos</a>
                <a class="nav-link active" href="minhas_reservas.php"><i class="fas fa-calendar-check me-1"></i>Minhas Reservas</a>
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Sair</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2><i class="fas fa-calendar-check me-2"></i>Minhas Reservas</h2>
        <p class="text-muted">Gerencie suas reservas de eventos culturais</p>

        <?php if (isset($_SESSION['sucesso'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="fas fa-check-circle me-2"></i><?php echo $_SESSION['sucesso']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['sucesso']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['erro'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $_SESSION['erro']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
            <?php unset($_SESSION['erro']); ?>
        <?php endif; ?>

        <?php if (count($reservas) > 0): ?>
            <div class="row" id="reservas-container">
                <?php foreach ($reservas as $reserva): ?>
                    <div class="col-md-6 mb-3 reserva-item">
                        <div class="card h-100">
                            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                <span>
                                    <i class="fas fa-ticket-alt me-1"></i>
                                    Confirmada
                                </span>
                                <span class="badge bg-light text-dark">
                                    <?php echo date('d/m/Y', strtotime($reserva['data_reserva'])); ?>
                                </span>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $reserva['evento_nome']; ?></h5>
                                <p class="card-text text-muted small"><?php echo $reserva['descricao']; ?></p>
                                
                                <div class="mb-2">
                                    <i class="fas fa-map-marker-alt text-primary me-1"></i>
                                    <small><?php echo $reserva['local']; ?></small>
                                </div>
                                
                                <div class="mb-2">
                                    <i class="fas fa-calendar text-primary me-1"></i>
                                    <small><?php echo date('d/m/Y', strtotime($reserva['data_evento'])); ?></small>
                                </div>
                                
                                <div class="mb-3">
                                    <i class="fas fa-clock text-primary me-1"></i>
                                    <small><?php echo date('H:i', strtotime($reserva['hora'])); ?>h</small>
                                </div>

                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="badge bg-primary">
                                        <i class="fas fa-users me-1"></i>
                                        <?php echo $reserva['quantidade_pessoas']; ?> pessoa(s)
                                    </span>
                                    
                                    <!-- CORREÇÃO: Botão Cancelar com JavaScript -->
                                    <button onclick="cancelarReserva(this, <?php echo $reserva['id_reserva']; ?>)" 
                                            class="btn btn-outline-danger btn-sm">
                                        <i class="fas fa-times me-1"></i>Cancelar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5" id="no-reservas-message">
                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                <h4 class="text-muted">Nenhuma reserva encontrada</h4>
                <p class="text-muted">Você ainda não fez nenhuma reserva.</p>
                <a href="evento.php" class="btn btn-primary">
                    <i class="fas fa-calendar-alt me-2"></i>Ver Eventos Disponíveis
                </a>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Função para cancelar reserva com confirmação e remoção instantânea
    function cancelarReserva(btn, idReserva) {
        if (confirm('Tem certeza que deseja cancelar esta reserva?')) {
            // Desabilitar o botão para evitar múltiplos cliques
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Cancelando...';
            
            // Fazer a requisição para cancelar
            fetch('cancelar_reserva.php?id=' + idReserva)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Encontrar e remover o card da reserva
                        const card = btn.closest('.col-md-6');
                        card.style.opacity = '0';
                        card.style.transition = 'opacity 0.5s ease';
                        
                        setTimeout(() => {
                            card.remove();
                            
                            // Mostrar mensagem de sucesso
                            showMessage(data.message, 'success');
                            
                            // Se não houver mais reservas, mostrar mensagem
                            const reservasContainer = document.getElementById('reservas-container');
                            if (reservasContainer && reservasContainer.children.length === 0) {
                                showNoReservasMessage();
                            }
                        }, 500);
                        
                    } else {
                        // Mostrar mensagem de erro
                        showMessage(data.message, 'error');
                        btn.disabled = false;
                        btn.innerHTML = '<i class="fas fa-times me-1"></i>Cancelar';
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                    showMessage('Erro ao cancelar reserva. Tente novamente.', 'error');
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-times me-1"></i>Cancelar';
                });
        }
    }

    // Função para mostrar mensagens
    function showMessage(message, type) {
        const alertClass = type === 'success' ? 'alert-success' : 'alert-danger';
        const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle';
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert ${alertClass} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            <i class="fas ${icon} me-2"></i>${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Inserir no topo do container
        const container = document.querySelector('.container');
        const title = container.querySelector('h2');
        container.insertBefore(alertDiv, title.nextElementSibling);
        
        // Remover automaticamente após 5 segundos
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    // Função para mostrar mensagem quando não há reservas
    function showNoReservasMessage() {
        const mainContent = document.querySelector('.container .row');
        mainContent.innerHTML = `
            <div class="col-12">
                <div class="text-center py-5">
                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">Nenhuma reserva encontrada</h4>
                    <p class="text-muted">Você ainda não fez nenhuma reserva.</p>
                    <a href="evento.php" class="btn btn-primary">
                        <i class="fas fa-calendar-alt me-2"></i>Ver Eventos Disponíveis
                    </a>
                </div>
            </div>
        `;
    }
    </script>
</body>
</html>