<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] !== 'admin') {
    header("Location: login.php");
    exit();
}

require_once 'config/database.php';
$database = new Database();
$db = $database->getConnection();

// Adicionar novo evento
if ($_POST && isset($_POST['adicionar_evento'])) {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $local = $_POST['local'];
    $endereco = $_POST['endereco'];
    $data_evento = $_POST['data_evento'];
    $hora = $_POST['hora'];
    $capacidade = $_POST['capacidade'];
    
    // QUERY CORRIGIDA - removido 'criado_por'
    $query = "INSERT INTO eventos (nome, descricao, local, endereco_completo, data_evento, hora, capacidade) 
              VALUES (:nome, :descricao, :local, :endereco, :data_evento, :hora, :capacidade)";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":nome", $nome);
    $stmt->bindParam(":descricao", $descricao);
    $stmt->bindParam(":local", $local);
    $stmt->bindParam(":endereco", $endereco);
    $stmt->bindParam(":data_evento", $data_evento);
    $stmt->bindParam(":hora", $hora);
    $stmt->bindParam(":capacidade", $capacidade);
    
    if ($stmt->execute()) {
        $sucesso = "Evento adicionado com sucesso!";
    } else {
        $erro = "Erro ao adicionar evento.";
    }
}

// Buscar eventos
$query = "SELECT * FROM eventos ORDER BY data_evento DESC";
$stmt = $db->prepare($query);
$stmt->execute();
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar estatísticas
$query_stats = "SELECT 
    COUNT(*) as total_eventos,
    SUM(capacidade) as total_vagas,
    (SELECT COUNT(*) FROM reservas WHERE status = 'A') as total_reservas
    FROM eventos";
$stmt_stats = $db->prepare($query_stats);
$stmt_stats->execute();
$stats = $stmt_stats->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin - Reservas Culturais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --gradient: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        }
        
        body {
            background: #f8fafc;
            font-family: 'Inter', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            color: white;
            min-height: 100vh;
            position: fixed;
            width: 280px;
        }
        
        .main-content {
            margin-left: 280px;
            padding: 0;
        }
        
        .navbar-admin {
            background: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 1rem 2rem;
        }
        
        .admin-header {
            background: var(--gradient);
            color: white;
            padding: 3rem 2rem;
        }
        
        .stats-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 4px solid var(--primary);
            transition: transform 0.2s;
        }
        
        .stats-card:hover {
            transform: translateY(-2px);
        }
        
        .btn-admin {
            background: var(--gradient);
            border: none;
            border-radius: 8px;
            padding: 10px 20px;
            color: white;
            font-weight: 600;
        }
        
        .evento-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
        }
        
        .logo-admin {
            font-size: 1.8rem;
            font-weight: 700;
            padding: 2rem 1.5rem 1rem;
            border-bottom: 1px solid #10081620;
        }
        
        .nav-admin {
            padding: 1rem 0;
        }
        
        .nav-admin a {
            color: #cbd5e1;
            text-decoration: none;
            padding: 0.75rem 1.5rem;
            display: block;
            transition: all 0.3s;
        }
        
        .nav-admin a:hover, .nav-admin a.active {
            color: white;
            background: rgba(162, 65, 207, 0.1);
            border-left: 4px solid var(--primary);
        }
        
        .nav-admin i {
            width: 20px;
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo-admin">
            <i class="fas fa-crown me-2"></i>Admin Painel
        </div>
        
        <div class="nav-admin">
            <a href="#" class="active">
                <i class="fas fa-tachometer-alt"></i>Dashboard
            </a>
            <a href="#adicionar-evento">
                <i class="fas fa-plus-circle"></i>Adicionar Evento
            </a>
            <a href="admin_eventos.php">
                <i class="fas fa-calendar-alt"></i>Gerenciar Eventos
            </a>
            <a href="dashboard.php">
                <i class="fas fa-eye"></i>Ver como Usuário
            </a>
            <a href="logout.php">
                <i class="fas fa-sign-out-alt"></i>Sair
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar Top -->
        <nav class="navbar-admin">
            <div class="d-flex justify-content-between align-items-center w-100">
                <h4 class="mb-0">Painel de Controle</h4>
                <div class="d-flex align-items-center">
                    <span class="me-3">Olá, <?php echo $_SESSION['usuario_nome']; ?></span>
                    <div class="bg-primary text-white rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                        <i class="fas fa-user-shield"></i>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Header -->
        <div class="admin-header">
            <div class="container-fluid">
                <h1 class="display-5 fw-bold">Bem-vindo, Administrador! 👑</h1>
                <p class="lead mb-0">Gerencie eventos e reservas do sistema</p>
            </div>
        </div>

        <!-- Content -->
        <div class="container-fluid py-4">
            <!-- Estatísticas -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="bg-primary bg-opacity-10 rounded p-3 me-3">
                                <i class="fas fa-calendar text-primary fa-2x"></i>
                            </div>
                            <div>
                                <h3 class="fw-bold mb-0"><?php echo $stats['total_eventos']; ?></h3>
                                <p class="text-muted mb-0">Eventos Ativos</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="bg-success bg-opacity-10 rounded p-3 me-3">
                                <i class="fas fa-users text-success fa-2x"></i>
                            </div>
                            <div>
                                <h3 class="fw-bold mb-0"><?php echo $stats['total_vagas']; ?></h3>
                                <p class="text-muted mb-0">Total de Vagas</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stats-card">
                        <div class="d-flex align-items-center">
                            <div class="bg-warning bg-opacity-10 rounded p-3 me-3">
                                <i class="fas fa-ticket-alt text-warning fa-2x"></i>
                            </div>
                            <div>
                                <h3 class="fw-bold mb-0"><?php echo $stats['total_reservas']; ?></h3>
                                <p class="text-muted mb-0">Reservas Ativas</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <!-- NOVO CARD - Gerenciar Eventos -->
                    <div class="stats-card bg-success text-white">
                        <div class="d-flex align-items-center">
                            <div class="bg-white bg-opacity-20 rounded p-3 me-3">
                                <i class="fas fa-cog fa-2x"></i>
                            </div>
                            <div>
                                <h5 class="fw-bold mb-0">Gerenciar</h5>
                                <p class="mb-0 opacity-75">Todos os Eventos</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <a href="admin_eventos.php" class="btn btn-light btn-sm w-100">
                                <i class="fas fa-arrow-right me-1"></i>Acessar
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Adicionar Evento -->
            <div class="row mb-5" id="adicionar-evento">
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-primary text-white">
                            <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Adicionar Novo Evento</h5>
                        </div>
                        <div class="card-body">
                            <?php if (isset($sucesso)): ?>
                                <div class="alert alert-success"><?php echo $sucesso; ?></div>
                            <?php endif; ?>
                            <?php if (isset($erro)): ?>
                                <div class="alert alert-danger"><?php echo $erro; ?></div>
                            <?php endif; ?>
                            
                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Nome do Evento</label>
                                        <input type="text" class="form-control" name="nome" placeholder="Ex: Festival de Música" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-semibold">Local</label>
                                        <input type="text" class="form-control" name="local" placeholder="Ex: Teatro Municipal" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Endereço Completo</label>
                                    <input type="text" class="form-control" name="endereco" placeholder="Ex: Av. Principal, 123 - Centro, São Paulo - SP" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Descrição</label>
                                    <textarea class="form-control" name="descricao" rows="3" placeholder="Descreva o evento..." required></textarea>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Data do Evento</label>
                                        <input type="date" class="form-control" name="data_evento" required>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Horário</label>
                                        <input type="time" class="form-control" name="hora" required>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <label class="form-label fw-semibold">Capacidade</label>
                                        <input type="number" class="form-control" name="capacidade" placeholder="Número de vagas" required>
                                    </div>
                                </div>
                                
                                <button type="submit" name="adicionar_evento" class="btn btn-admin">
                                    <i class="fas fa-save me-2"></i>Adicionar Evento
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gerenciar Eventos -->
            <div class="row" id="gerenciar-eventos">
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-success text-white">
                            <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Eventos Cadastrados</h5>
                        </div>
                        <div class="card-body">
                            <?php if (empty($eventos)): ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                                    <h5 class="text-muted">Nenhum evento cadastrado</h5>
                                    <p class="text-muted">Adicione seu primeiro evento usando o formulário acima.</p>
                                </div>
                            <?php else: ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Evento</th>
                                                <th>Local</th>
                                                <th>Data</th>
                                                <th>Capacidade</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($eventos as $evento): ?>
                                            <tr>
                                                <td>
                                                    <strong><?php echo $evento['nome']; ?></strong>
                                                    <br><small class="text-muted"><?php echo substr($evento['descricao'], 0, 50); ?>...</small>
                                                </td>
                                                <td><?php echo $evento['local']; ?></td>
                                                <td>
                                                    <?php echo date('d/m/Y', strtotime($evento['data_evento'])); ?>
                                                    <br><small><?php echo date('H:i', strtotime($evento['hora'])); ?></small>
                                                </td>
                                                <td><?php echo $evento['capacidade']; ?> vagas</td>
                                                <td>
                                                    <a href="admin_eventos.php" class="btn btn-sm btn-outline-primary me-1">
                                                        <i class="fas fa-cog"></i> Gerenciar
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Data mínima para o campo de data (hoje)
        document.querySelector('input[name="data_evento"]').min = new Date().toISOString().split('T')[0];
    </script>
</body>
</html>