<?php
session_start();
require_once 'config/database.php';

// Verificar se usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Buscar eventos futuros
$query = "SELECT * FROM eventos WHERE data_evento >= CURDATE() ORDER BY data_evento ASC";
$stmt = $db->prepare($query);
$stmt->execute();
$eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventos - Reservas Culturais</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .evento-card {
            transition: transform 0.3s ease;
            margin-bottom: 20px;
        }
        .evento-card:hover {
            transform: translateY(-5px);
        }
        .badge-disponivel {
            background: #28a745;
        }
        .badge-lotado {
            background: #dc3545;
        }
    </style>
</head>
<body>
    <!-- Navbar CORRIGIDA -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="fas fa-theater-masks me-2"></i>Reservas Culturais
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">Olá, <?php echo $_SESSION['usuario_nome']; ?>!</span>
                <a class="nav-link active" href="evento.php"><i class="fas fa-calendar me-1"></i>Eventos</a>
                <a class="nav-link" href="minhas_reservas.php"><i class="fas fa-calendar-check me-1"></i>Minhas Reservas</a>
                <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-1"></i>Sair</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2><i class="fas fa-calendar-alt me-2"></i>Eventos Disponíveis</h2>
        <p class="text-muted">Confira os eventos e faça sua reserva</p>

        <div class="row">
            <?php if (count($eventos) > 0): ?>
                <?php foreach ($eventos as $evento): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card evento-card">
                            <?php if ($evento['imagem']): ?>
                                <img src="<?php echo $evento['imagem']; ?>" class="card-img-top" alt="<?php echo $evento['nome']; ?>" style="height: 200px; object-fit: cover;">
                            <?php else: ?>
                                <div class="card-img-top bg-secondary d-flex align-items-center justify-content-center" style="height: 200px;">
                                    <i class="fas fa-image fa-3x text-white-50"></i>
                                </div>
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $evento['nome']; ?></h5>
                                <p class="card-text text-muted small"><?php echo $evento['descricao']; ?></p>
                                
                                <div class="mb-2">
                                    <i class="fas fa-map-marker-alt text-primary me-1"></i>
                                    <small><?php echo $evento['local']; ?></small>
                                </div>
                                
                                <div class="mb-2">
                                    <i class="fas fa-calendar text-primary me-1"></i>
                                    <small><?php echo date('d/m/Y', strtotime($evento['data_evento'])); ?></small>
                                </div>
                                
                                <div class="mb-3">
                                    <i class="fas fa-clock text-primary me-1"></i>
                                    <small><?php echo date('H:i', strtotime($evento['hora'])); ?>h</small>
                                </div>

                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="badge bg-primary">Capacidade: <?php echo $evento['capacidade']; ?></span>
                                    <a href="detalhes_evento.php?id=<?php echo $evento['id_evento']; ?>" class="btn btn-success btn-sm">
                                        <i class="fas fa-ticket-alt me-1"></i>Fazer Reserva
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="alert alert-info text-center">
                        <i class="fas fa-info-circle me-2"></i>Nenhum evento disponível no momento.
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>