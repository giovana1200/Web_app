<?php
session_start();
require_once 'config/database.php';

// Verificar se é admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] != 'admin') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: admin_eventos.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Coletar dados do formulário
$nome = $_POST['nome'];
$descricao = $_POST['descricao'];
$local = $_POST['local'];
$endereco_completo = $_POST['endereco_completo'] ?? null;
$data_evento = $_POST['data_evento'];
$hora = $_POST['hora'];
$capacidade = $_POST['capacidade'];

// Processar upload de imagem
$imagem = null;
if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] === UPLOAD_ERR_OK) {
    $extensao = strtolower(pathinfo($_FILES['imagem']['name'], PATHINFO_EXTENSION));
    $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif'];
    
    if (in_array($extensao, $extensoes_permitidas)) {
        $nome_imagem = uniqid() . '.' . $extensao;
        $pasta_upload = 'uploads/';
        
        // Criar pasta se não existir
        if (!is_dir($pasta_upload)) {
            mkdir($pasta_upload, 0777, true);
        }
        
        $caminho_imagem = $pasta_upload . $nome_imagem;
        
        if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho_imagem)) {
            $imagem = $caminho_imagem;
        }
    }
}

try {
    // Inserir evento no banco
    $query = "INSERT INTO eventos (nome, descricao, local, endereco_completo, data_evento, hora, capacidade, imagem) 
              VALUES (:nome, :descricao, :local, :endereco_completo, :data_evento, :hora, :capacidade, :imagem)";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(":nome", $nome);
    $stmt->bindParam(":descricao", $descricao);
    $stmt->bindParam(":local", $local);
    $stmt->bindParam(":endereco_completo", $endereco_completo);
    $stmt->bindParam(":data_evento", $data_evento);
    $stmt->bindParam(":hora", $hora);
    $stmt->bindParam(":capacidade", $capacidade);
    $stmt->bindParam(":imagem", $imagem);

    if ($stmt->execute()) {
        $_SESSION['sucesso'] = "Evento '$nome' adicionado com sucesso! Já está disponível para os usuários.";
    } else {
        $_SESSION['erro'] = "Erro ao adicionar evento. Tente novamente.";
    }

} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro no sistema: " . $e->getMessage();
}

header("Location: admin_eventos.php");
exit();
?>