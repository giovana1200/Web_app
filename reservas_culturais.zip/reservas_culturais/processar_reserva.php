<?php
session_start();
require_once 'config/database.php';

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_tipo'] != 'usuario') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] != 'POST' || !isset($_POST['id_evento'])) {
    header("Location: evento.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$id_evento = $_POST['id_evento'];
$quantidade_pessoas = $_POST['quantidade_pessoas'];
$id_usuario = $_SESSION['usuario_id'];

try {
    // Verificar se evento existe e tem vagas
    $query_evento = "SELECT capacidade FROM eventos WHERE id_evento = :id_evento";
    $stmt_evento = $db->prepare($query_evento);
    $stmt_evento->bindParam(":id_evento", $id_evento);
    $stmt_evento->execute();
    $evento = $stmt_evento->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        $_SESSION['erro'] = "Evento não encontrado!";
        header("Location: evento.php");
        exit();
    }

    // Verificar total de reservas CONFIRMADAS já feitas
    $query_total = "SELECT SUM(quantidade_pessoas) as total FROM reservas WHERE id_evento = :id_evento AND status = 'confirmada'";
    $stmt_total = $db->prepare($query_total);
    $stmt_total->bindParam(":id_evento", $id_evento);
    $stmt_total->execute();
    $total_reservas = $stmt_total->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

    $vagas_disponiveis = $evento['capacidade'] - $total_reservas;

    if ($quantidade_pessoas > $vagas_disponiveis) {
        $_SESSION['erro'] = "Não há vagas suficientes para esta reserva! Vagas disponíveis: $vagas_disponiveis";
        header("Location: detalhes_evento.php?id=$id_evento");
        exit();
    }

    // CORREÇÃO: Verificar se usuário já tem reserva CONFIRMADA para este evento
    // Permite nova reserva se a anterior estiver cancelada
    $query_existente = "SELECT id_reserva FROM reservas WHERE id_usuario = :id_usuario AND id_evento = :id_evento AND status = 'confirmada'";
    $stmt_existente = $db->prepare($query_existente);
    $stmt_existente->bindParam(":id_usuario", $id_usuario);
    $stmt_existente->bindParam(":id_evento", $id_evento);
    $stmt_existente->execute();

    if ($stmt_existente->rowCount() > 0) {
        $_SESSION['erro'] = "Você já possui uma reserva CONFIRMADA para este evento!";
        header("Location: detalhes_evento.php?id=$id_evento");
        exit();
    }

    // Inserir nova reserva
    $query_inserir = "INSERT INTO reservas (id_usuario, id_evento, quantidade_pessoas, status) 
                     VALUES (:id_usuario, :id_evento, :quantidade_pessoas, 'confirmada')";
    $stmt_inserir = $db->prepare($query_inserir);
    $stmt_inserir->bindParam(":id_usuario", $id_usuario);
    $stmt_inserir->bindParam(":id_evento", $id_evento);
    $stmt_inserir->bindParam(":quantidade_pessoas", $quantidade_pessoas);

    if ($stmt_inserir->execute()) {
        $_SESSION['sucesso'] = "Reserva realizada com sucesso para $quantidade_pessoas pessoa(s)!";
        header("Location: minhas_reservas.php");
        exit();
    } else {
        $_SESSION['erro'] = "Erro ao realizar reserva. Tente novamente.";
        header("Location: detalhes_evento.php?id=$id_evento");
        exit();
    }

} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro no sistema: " . $e->getMessage();
    header("Location: evento.php");
    exit();
}
?>